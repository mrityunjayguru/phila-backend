const mysql =  require('mysql');

const connection = mysql.createConnection({
    host:'localhost',
    user :'root',
    password:'',
    database:'big_bus_live',
})


connection.connect((err)=>{
    if(err) throw err;
    console.log('connection success');
}) 

module.exports = connection;