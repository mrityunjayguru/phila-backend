
 const db = require('../database');
 
 const UpdateLocation = (response) => {  
    const final = response.data;
    final.map((res)=>{
        db.query(
            `UPDATE buses SET latitude = ? , longitude = ?, live_status = ? WHERE device_id = ?`,
            [res.latitude,res.longitude,res.status,res.deviceId],
            (error,results,fields)=>{              
                if(error){
                    callback(error);
                }
                console.log(results); 
               
            }
        )
    
    })

   



    

}


module.exports = UpdateLocation

